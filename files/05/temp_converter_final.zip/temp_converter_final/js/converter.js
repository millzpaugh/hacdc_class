document.getElementById('submit').onclick = convertTemp


function convertTemp(){
	var val = document.getElementById('f').value 

	val = parseInt(val)

	var celsiusTemp = (val - 32) * (5 / 9);

	document.getElementById('f').value = celsiusTemp
}