


$(document).ready(function(){
	$('div').on('click', function(){
		$(this).toggleClass('show-description'); 
		console.log('hits fxn'); 
	}); 
})



